# Dead Visuals

A client-side visual mod for **Minecraft 1.21.4** using Fabric.

## Features

- Custom dark ClickGUI with red/monochrome accent
- Open the menu with **Right Shift**
- Toggleable brand watermark, coordinates, FPS, compass direction, world time, movement speed and enabled-module list
- Non-pausing menu for use while in a world
- Java 21 toolchain

## Build

Install JDK 21 and use Gradle 8.12 or the compatible Gradle wrapper if provided by your IDE. From this directory run:

```bash
gradle build
```

The mod JAR will be written to `build/libs/`.

## Notes

This is an early source build. Test it in a separate Minecraft profile before using it in a main instance. No prebuilt JAR is included because the project has not been verified by a full Gradle build in this environment.
