package com.deadvisuals;

import com.deadvisuals.gui.DeadVisualsScreen;
import com.deadvisuals.module.VisualSettings;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DeadVisuals implements ClientModInitializer {
    public static final String MOD_ID = "deadvisuals";
    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.deadvisuals.open_gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.deadvisuals"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new DeadVisualsScreen());
                } else if (client.currentScreen instanceof DeadVisualsScreen) {
                    client.setScreen(null);
                }
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderHud(drawContext));
    }

    private static void renderHud(net.minecraft.client.gui.DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.options.hudHidden) return;

        int x = 8;
        int y = 8;
        int accent = VisualSettings.redAccent ? 0xFFFF354D : 0xFFE8E8EE;
        List<String> enabled = new ArrayList<>();

        if (VisualSettings.showBrand) {
            String brand = "DEAD VISUALS";
            int w = client.textRenderer.getWidth(brand) + 17;
            context.fill(x - 4, y - 3, x + w, y + 15, 0xC9101015);
            context.fill(x - 4, y - 3, x - 1, y + 15, accent);
            context.drawTextWithShadow(client.textRenderer, Text.literal("DEAD"), x + 2, y, 0xFFFFFFFF);
            context.drawTextWithShadow(client.textRenderer, Text.literal("VISUALS"), x + 37, y, accent);
            y += 22;
            enabled.add("Brand");
        }
        if (VisualSettings.showCoordinates) {
            String coords = String.format(Locale.ROOT, "XYZ  %d  %d  %d",
                    (int) client.player.getX(), (int) client.player.getY(), (int) client.player.getZ());
            y = drawPill(context, client, coords, x, y, 0xFFE8E8EC, accent);
            enabled.add("Coordinates");
        }
        if (VisualSettings.showFps) {
            y = drawPill(context, client, "FPS  " + client.getCurrentFps(), x, y, accent, accent);
            enabled.add("FPS");
        }
        if (VisualSettings.showDirection) {
            float yaw = client.player.getYaw();
            String[] directions = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
            int index = Math.floorMod(Math.round(yaw / 45.0f), 8);
            y = drawPill(context, client, "FACING  " + directions[index], x, y, 0xFFE8E8EC, accent);
            enabled.add("Direction");
        }
        if (VisualSettings.showWorldTime) {
            long time = Math.floorMod(client.world.getTimeOfDay() + 6000L, 24000L);
            long hours = (time / 1000L) % 24L;
            long minutes = (time % 1000L) * 60L / 1000L;
            y = drawPill(context, client, String.format(Locale.ROOT, "WORLD  %02d:%02d", hours, minutes), x, y, 0xFFE8E8EC, accent);
            enabled.add("World Time");
        }
        if (VisualSettings.showSpeed) {
            double horizontal = Math.sqrt(client.player.getVelocity().x * client.player.getVelocity().x
                    + client.player.getVelocity().z * client.player.getVelocity().z) * 20.0;
            y = drawPill(context, client, String.format(Locale.ROOT, "SPEED  %.2f m/s", horizontal), x, y, 0xFFE8E8EC, accent);
            enabled.add("Speed");
        }
        if (VisualSettings.showModuleList) {
            int rowY = 8;
            for (String module : enabled) {
                int textW = client.textRenderer.getWidth(module);
                int right = client.getWindow().getScaledWidth() - 8;
                context.fill(right - textW - 13, rowY - 3, right + 1, rowY + 11, 0xA80B0B10);
                context.fill(right, rowY - 3, right + 1, rowY + 11, accent);
                context.drawTextWithShadow(client.textRenderer, Text.literal(module), right - textW - 6, rowY, 0xFFEDEDF2);
                rowY += 16;
            }
        }
    }

    private static int drawPill(net.minecraft.client.gui.DrawContext context, MinecraftClient client,
                                String label, int x, int y, int textColor, int accent) {
        int width = client.textRenderer.getWidth(label);
        context.fill(x - 4, y - 3, x + width + 7, y + 12, 0xB80A0A0E);
        context.fill(x - 4, y - 3, x - 2, y + 12, accent);
        context.drawTextWithShadow(client.textRenderer, Text.literal(label), x, y, textColor);
        return y + 17;
    }
}
