package com.deadvisuals.gui;

import com.deadvisuals.module.VisualSettings;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Animated-styled, non-pausing ClickGUI for Dead Visuals. */
public final class DeadVisualsScreen extends Screen {
    private static final int PANEL_W = 326;
    private static final int PANEL_H = 310;
    private int left;
    private int top;
    private long openedAt;

    public DeadVisualsScreen() {
        super(Text.literal("Dead Visuals"));
    }

    @Override
    protected void init() {
        openedAt = System.currentTimeMillis();
        left = (width - PANEL_W) / 2;
        top = Math.max(8, (height - PANEL_H) / 2);
        clearChildren();

        int bx = left + 16;
        int bw = PANEL_W - 32;
        int bh = 20;
        int gap = 25;
        addToggle(bx, top + 77, bw, bh, "Brand watermark", () -> VisualSettings.showBrand, v -> VisualSettings.showBrand = v);
        addToggle(bx, top + 77 + gap, bw, bh, "Coordinates  /  XYZ", () -> VisualSettings.showCoordinates, v -> VisualSettings.showCoordinates = v);
        addToggle(bx, top + 77 + gap * 2, bw, bh, "FPS counter", () -> VisualSettings.showFps, v -> VisualSettings.showFps = v);
        addToggle(bx, top + 77 + gap * 3, bw, bh, "Direction  /  compass", () -> VisualSettings.showDirection, v -> VisualSettings.showDirection = v);
        addToggle(bx, top + 77 + gap * 4, bw, bh, "World time", () -> VisualSettings.showWorldTime, v -> VisualSettings.showWorldTime = v);
        addToggle(bx, top + 77 + gap * 5, bw, bh, "Movement speed", () -> VisualSettings.showSpeed, v -> VisualSettings.showSpeed = v);
        addToggle(bx, top + 77 + gap * 6, bw, bh, "Enabled module list", () -> VisualSettings.showModuleList, v -> VisualSettings.showModuleList = v);
    }

    private void addToggle(int x, int y, int w, int h, String label,
                           BooleanSupplier getter, Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(buttonText(label, getter.getAsBoolean()), button -> {
            setter.accept(!getter.getAsBoolean());
            button.setMessage(buttonText(label, getter.getAsBoolean()));
        }).dimensions(x, y, w, h).build());
    }

    private Text buttonText(String label, boolean enabled) {
        return Text.literal(label + "     " + (enabled ? "● ON" : "○ OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        left = (width - PANEL_W) / 2;
        top = Math.max(8, (height - PANEL_H) / 2);

        // Short fade-in without relying on a rendering library.
        float fade = Math.min(1.0f, (System.currentTimeMillis() - openedAt) / 180.0f);
        int alpha = ((int) (0xC8 * fade)) << 24;
        context.fill(0, 0, width, height, 0x99000000);
        int accent = VisualSettings.redAccent ? 0xFFFF354D : 0xFFE8E8EE;
        context.fill(left - 1, top - 1, left + PANEL_W + 1, top + PANEL_H + 1, accent);
        context.fill(left, top, left + PANEL_W, top + PANEL_H, 0xF00B0B10 | alpha);
        context.fill(left, top, left + PANEL_W, top + 3, accent);
        context.fill(left + 14, top + 48, left + PANEL_W - 14, top + 49, 0xFF303038);
        context.drawTextWithShadow(textRenderer, Text.literal("DEAD"), left + 16, top + 15, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("VISUALS"), left + 57, top + 15, accent);
        context.drawTextWithShadow(textRenderer, Text.literal("CLIENT-SIDE VISUALS  /  1.21.4"), left + 16, top + 32, 0xFF9696A2);
        context.drawTextWithShadow(textRenderer, Text.literal("HUD & OVERLAY"), left + 16, top + 57, 0xFFE5E5EA);
        context.drawTextWithShadow(textRenderer, Text.literal("RIGHT SHIFT  •  CLOSE"), left + 16, top + PANEL_H - 17, 0xFF858590);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
