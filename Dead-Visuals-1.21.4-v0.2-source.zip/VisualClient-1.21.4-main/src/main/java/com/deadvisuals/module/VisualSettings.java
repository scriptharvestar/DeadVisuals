package com.deadvisuals.module;

/** Client-side visual toggles used by the Dead Visuals HUD and ClickGUI. */
public final class VisualSettings {
    private VisualSettings() {}

    public static boolean showBrand = true;
    public static boolean showCoordinates = true;
    public static boolean showFps = true;
    public static boolean showDirection = true;
    public static boolean showWorldTime = false;
    public static boolean showSpeed = true;
    public static boolean showModuleList = true;
    public static boolean redAccent = true;
}
